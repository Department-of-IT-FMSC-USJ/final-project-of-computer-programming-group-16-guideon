"""
session_manager.py
File-based session persistence for Bridora.
No external packages required.
"""

import json
import os
import streamlit as st

SESSION_FILE = os.path.join("data", "session.json")


def _load() -> dict:
    """Read the session file."""
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save(data: dict):
    """Write session data to file."""
    os.makedirs("data", exist_ok=True)
    with open(SESSION_FILE, "w") as f:
        json.dump(data, f, indent=2)


def restore_sessions():
    """
    Restore logins from file into session_state.
    Only call this on a FRESH page load (when session_state was empty).
    Do NOT call on reruns — it would undo logout.
    """
    data = _load()

    if "customer" in data:
        st.session_state.customer = data["customer"]

    if data.get("is_vendor") and "shop_data" in data:
        st.session_state.is_vendor = True
        st.session_state.shop_data = data["shop_data"]

    if data.get("is_admin"):
        st.session_state.is_admin = True


def sync_sessions():
    """
    Write current login state to file.
    Call this at the bottom of app.py on every render.
    Handles both login (saves data) and logout (clears data).
    """
    data = {}
    if "customer" in st.session_state:
        data["customer"] = st.session_state.customer
    if "is_vendor" in st.session_state:
        data["is_vendor"] = True
        data["shop_data"] = st.session_state.get("shop_data", {})
    if "is_admin" in st.session_state:
        data["is_admin"] = True
    _save(data)

import streamlit as st
import pandas as pd
from storage import load_json, add_record
from backend import submit_booking, verify_login, check_duplicate_account

def render_home():
    """Home View: Welcome page for brides."""
    st.markdown("""
        <style>
        .main .block-container {
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            padding-top: 5rem !important;
            width: 100% !important;
        }
        .main [data-testid="stVerticalBlock"], 
        .main [data-testid="stVerticalBlock"] > div,
        .main [data-testid="element-container"] {
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            justify-content: center !important;
            width: 100% !important;
            text-align: center !important;
        }
        .main h1, .main h2, .main h3, .main .stMarkdown, .main p, .main .stCaption, .main .stSubheader {
            text-align: center !important;
            width: 100% !important;
        }
        .main [data-testid="stImage"] img { 
            border-radius: 50% !important; 
            border: 3px solid #FF69B4 !important;
            aspect-ratio: 1/1 !important;
            object-fit: cover !important;
            width: 250px !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
            margin-bottom: 20px !important;
        }
        .main .stButton button {
            width: 300px !important;
            margin-top: 30px !important;
            color: white !important;
            border: 1px solid #000000 !important;
            padding: 10px 20px !important;
            font-weight: bold !important;
        }
        </style>
        """, unsafe_allow_html=True)

    import base64, os
    logo_path = "assets/bridoralogo.jpeg"
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            logo_b64 = base64.b64encode(f.read()).decode()
        st.markdown(f"""
            <div style="display:flex; flex-direction:column; align-items:center; width:100%; margin-bottom:20px;">
                <img src="data:image/jpeg;base64,{logo_b64}"
                     style="width:250px; height:250px; border-radius:50%; 
                            border:5px solid #FF69B4; object-fit:cover;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.2);" />
            </div>
        """, unsafe_allow_html=True)

    st.markdown('<h1 style="text-align:center;">💖 Bridora</h1>', unsafe_allow_html=True)
    st.markdown('<h3 style="text-align:center; font-weight:400;">Your Dream Wedding, Found One Set at a Time.</h3>', unsafe_allow_html=True)
    st.markdown('<p style="text-align:center; color:gray;">Sri Lanka\'s Exclusive Bridal Jewelry Marketplace</p>', unsafe_allow_html=True)
    st.markdown('<p style="text-align:center; max-width:600px; margin:0 auto;">Bridora is a specialized platform for brides and jewelry shops in Sri Lanka. Browse through extensive collections of the finest Gold sets.</p>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("Browse Catalog", key="master_center_btn", use_container_width=True):
            st.session_state.page = "browse"
            st.rerun()


def render_browse():
    st.title("Browse Jewelry")
    jewelry_data = load_json('jewelry.json')
    shops_data = load_json('shops.json')
    
    active_shop_ids = [s.get('id') for s in shops_data]
    jewelry_data = [item for item in jewelry_data if item.get('shop_id') in active_shop_ids]
    
    if not jewelry_data:
        st.info("No jewelry items available right now. Check back later!")
        return

    col1, col2, col3 = st.columns(3)
    with col1:
        price_range = st.slider("Max Price (LKR)", 1000, 500000, 500000)
    with col2:
        style_choice = st.multiselect("Styles", ["Temple", "Gold", "Modern"], default=["Temple", "Gold", "Modern"])
    with col3:
        available_only = st.checkbox("Available Only", value=True)
    
    filtered_items = [
        item for item in jewelry_data 
        if item.get('price', 0) <= price_range 
        and item.get('style') in style_choice
        and (not available_only or item.get('availability', 'Yes') == 'Yes')
    ]
    
    if not filtered_items:
        st.warning("No items match your filters.")
    else:
        for i in range(0, len(filtered_items), 2):
            cols = st.columns(2)
            for j in range(2):
                if i + j < len(filtered_items):
                    item = filtered_items[i+j]
                    with cols[j]:
                        img_path = item.get('image_url', "https://via.placeholder.com/300x300?text=No+Preview")

                        import os
                        if img_path and os.path.exists(img_path):
                            st.image(img_path, width=350)
                        else:
                            st.image("https://via.placeholder.com/300x300?text=No+Preview", width=350)

                        st.subheader(item['name'])
                        st.write(f"**Style:** {item['style']}")
                        st.write(f"**Price:** LKR {item['price']}")
                        st.write(f"**Shop:** {item.get('shop_name', 'Verified Shop')}")
                        if st.button(f"View Details", key=f"details_{item['id']}"):
                            st.session_state.selected_item = item
                            st.session_state.page = "details"
                            st.rerun()


def render_details():
    if 'selected_item' not in st.session_state:
        st.session_state.page = "browse"
        st.rerun()
        
    item = st.session_state.selected_item
    st.title(f"{item['name']}")
    col1, col2 = st.columns(2)
    with col1:
        img_path = item.get('image_url', "https://via.placeholder.com/600x400?text=Premium+Bridal+Set")

        import os
        if img_path and os.path.exists(img_path):
            st.image(img_path, use_container_width=True)
        else:
            st.image("https://via.placeholder.com/600x400?text=Premium+Bridal+Set", use_container_width=True)

    with col2:
        st.subheader(f"Price: LKR {item['price']}")
        st.write(f"**Style:** {item['style']}")
        st.write(f"**Shop:** {item.get('shop_name', 'Verified Vendor')}")
        
        item_type_raw = item.get('type', [])
        if isinstance(item_type_raw, list):
            type_label = " & ".join(item_type_raw)
        else:
            type_label = item_type_raw
        st.write(f"**Available for:** {type_label if type_label else 'N/A'}")

        qty = item.get('quantity', None)
        if qty is not None:
            qty_color = "green" if qty > 0 else "red"
            qty_label = f"{qty} in stock" if qty > 0 else "Out of stock"
            st.markdown(f"**Quantity:** :{qty_color}[{qty_label}]")

        st.write(f"**Status:** {item.get('availability', 'Available')}")
        st.info("Perfect for: Wedding ceremonies, engagements, and formal events.")
        
        if st.button("⬅️ Back to Browse"):
            st.session_state.page = "browse"
            st.rerun()
            
    st.divider()
    st.subheader("📅 Reserve This Set")

    if 'customer' not in st.session_state:
        st.warning("🔒 You need to be logged in as a customer to make a reservation.")
        return